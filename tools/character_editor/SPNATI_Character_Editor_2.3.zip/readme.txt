1. Extract all files in this archive to somewhere on your computer.
2. Make sure you've downloaded the SPNATI source from the GitLab repository.
3. Run SPNATI Character Editor.exe
4. If this is your first time, you will be asked to browse to the SPNATI Repository. Navigate to where you downloaded the files and select the root folder (the one that contains css, fonts, js, opponents, etc.)
5. Once in the editor Go to Help > View Help for more detailed documentation about using the character editor.


IMPORTANT: If you are looking at this in the GitLab repository, SPNATI Character Editor.exe is not here. Get it from https://www.reddit.com/r/spnati/comments/7071mz/character_editor_official_release/